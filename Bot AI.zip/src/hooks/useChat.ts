import { useState, useCallback } from "react";
import { toast } from "sonner";

export interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
}

export const useChat = (webhookUrl: string) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = useCallback(
    async (content: string) => {
      if (!webhookUrl) {
        toast.error("Silakan masukkan URL webhook n8n terlebih dahulu");
        return;
      }

      const userMessage: Message = {
        id: Date.now().toString(),
        content,
        role: "user",
      };

      setMessages((prev) => [...prev, userMessage]);
      setIsLoading(true);

      try {
        const response = await fetch(webhookUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ message: content }),
        });

        if (!response.ok) {
          throw new Error("Gagal menghubungi webhook");
        }

        const data = await response.json();
        
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: data.response || data.output || data.message || JSON.stringify(data),
          role: "assistant",
        };

        setMessages((prev) => [...prev, assistantMessage]);
      } catch (error) {
        console.error("Error sending message:", error);
        toast.error("Gagal mengirim pesan. Periksa URL webhook Anda.");
        
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: "Maaf, terjadi kesalahan saat menghubungi server. Pastikan URL webhook n8n Anda benar dan aktif.",
          role: "assistant",
        };
        setMessages((prev) => [...prev, errorMessage]);
      } finally {
        setIsLoading(false);
      }
    },
    [webhookUrl]
  );

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  return {
    messages,
    isLoading,
    sendMessage,
    clearMessages,
  };
};
