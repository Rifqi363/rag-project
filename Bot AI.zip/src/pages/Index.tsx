import { useState, useRef, useEffect } from "react";
import { Bot, Trash2, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import ChatMessage from "@/components/ChatMessage";
import ChatInput from "@/components/ChatInput";
import WebhookSettings from "@/components/WebhookSettings";
import { useChat } from "@/hooks/useChat";

const Index = () => {
  const [webhookUrl, setWebhookUrl] = useState(() => {
    return localStorage.getItem("n8n_webhook_url") || "";
  });

  const { messages, isLoading, sendMessage, clearMessages } = useChat(webhookUrl);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleSaveWebhook = (url: string) => {
    setWebhookUrl(url);
    localStorage.setItem("n8n_webhook_url", url);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b bg-card">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
            <Bot className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">AI Chatbot</h1>
            <p className="text-xs text-muted-foreground">
              {webhookUrl ? "Terhubung ke n8n" : "Belum terhubung"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {messages.length > 0 && (
            <Button
              variant="ghost"
              size="icon"
              onClick={clearMessages}
              className="rounded-full text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
          <WebhookSettings webhookUrl={webhookUrl} onSave={handleSaveWebhook} />
        </div>
      </header>

      {/* Chat Area */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[60vh] text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-secondary mb-6">
                <MessageSquare className="h-10 w-10 text-muted-foreground" />
              </div>
              <h2 className="text-2xl font-semibold text-foreground mb-2">
                Selamat Datang!
              </h2>
              <p className="text-muted-foreground max-w-md mb-6">
                Chatbot ini terhubung dengan n8n workflow. Klik tombol pengaturan
                untuk memasukkan URL webhook n8n Anda, lalu mulai percakapan.
              </p>
              {!webhookUrl && (
                <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-4 py-2 rounded-lg">
                  <span>⚠️</span>
                  <span>Masukkan URL webhook terlebih dahulu</span>
                </div>
              )}
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  content={message.content}
                  role={message.role}
                />
              ))}
              {isLoading && (
                <ChatMessage content="" role="assistant" isLoading />
              )}
            </>
          )}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="border-t bg-card p-4">
        <div className="max-w-3xl mx-auto">
          <ChatInput onSend={sendMessage} disabled={isLoading} />
        </div>
      </div>
    </div>
  );
};

export default Index;
